<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>No tienes permisos</title>
    <link rel="stylesheet" href="<?php echo base_url; ?>Assets/css/estilos.css">
</head>

<body>

    <div class="content">
        <a href="<?php echo base_url; ?>Administracion/home" class="pagina">Regresar</a>
        <hr>
        <span class="tags">No tiene permisos</span>
        <p>El administrador no te asigno el permiso a este módulo.</p>
    </div>

</body>

</html>